package cmryun

import (
	"net/http"
	"strings"
)

const (
	COOKIE_VALID_TIME        = 60
	TOP_DOMAIN               = "cmr.net.cn"
	AGENCY_COOKIE_PID        = ";zs;hc;poly;bigc;zlg;demo;zgbx;muc;cmr;md;xxkd;hcy;cjbz;"
	VALID_FRONT_REF_PID      = ";zgbx;"
	APPROVAL_DEPT_COOKIE_PID = ";cnu;mdpx;"
	TIME_FORMAT              = "2006-01-02 15:04:05"
)

var SysDomain map[string]string
var Protocol string
var Evn string
var ValidUrlApi []string
var ValidUrlPage []string
var ValidUrl []string
var ValidServerIp map[string][]string

func Init(r *http.Request) {
	Protocol = "http"

	if r.TLS != nil {
		Protocol = "https"
	}
	Evn = ""
	if strings.Index(r.Host, "dev") == 0 {
		Evn = "dev"
	}
	if strings.Index(r.Host, "cs") == 0 {
		Evn = "cs"
	}
	SysDomain = map[string]string{
		"authSysDomain":   "userauth",
		"sysManageDomain": "sysmanage",
	}
	ValidUrlApi = []string{
		SysDomain["authSysDomain"] + "/auth/intf/menuInfoMultiple",
		SysDomain["authSysDomain"] + "/public/OAuth",
	}
	ValidUrlPage = []string{
		SysDomain["authSysDomain"] + "/reg/registration/LoginCode",
		SysDomain["authSysDomain"] + "/reg/registration/logout",
		"http://test.cmr.net.cn/index",
		"http://test.cmr.net.cn/ajax",
	}
	ValidUrl = MergeSlice(ValidUrlApi, ValidUrlPage)

	ValidServerIp = make(map[string][]string)
	ValidServerIp["all"] = []string{
		"103.233.128.137",
		"103.233.128.182",
		"103.233.128.183",
		"103.233.128.184",
		"103.233.128.185",
		"103.233.128.188",
		"103.233.128.189",
		"103.233.128.237",
		"103.233.128.154",
		"172.16.252.100",
		"172.16.252.60",
		"172.16.252.61",
		"172.16.252.62",
		"172.16.252.63",
		"172.16.252.182", //'product
		"172.16.252.183", //'userauth
		"172.16.252.184", //'sysmanage
		"172.16.252.185", //'wpt
		"172.16.252.188", //'message
		"172.16.252.189", //'usersign
		"172.16.252.232",
		"103.233.128.154", //'开发其它站点
		"103.233.128.155", //'测试其它站点
		"103.233.128.129", //'开发其它站点
		"103.233.128.130", //'测试其它站点
		"172.16.252.113",
		"172.16.252.171",
		"172.16.252.93",
		"172.16.252.91",
		"127.0.0.1",
	}
	ValidServerIp["zgbx"] = []string{
		"172.16.30.21",
	}
	ValidServerIp["wis"] = []string{
		"172.16.30.21",
	}
}

func GetDomain(key string) string {
	return Protocol + "://" + Evn + SysDomain[key] + "." + TOP_DOMAIN
}
