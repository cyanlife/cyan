package cmryun

import (
	"io/ioutil"
	"log"

	"gopkg.in/yaml.v2"
)

var config map[interface{}]interface{}

func GetConfig() (e map[interface{}]interface{}) {
	return config
}

func InitConfig() {
	var err error
	configFile, err := ioutil.ReadFile("config.yaml")
	if err != nil {
		configFile, err = ioutil.ReadFile("../cmd/report/config.yaml")
		if err != nil {
			log.Fatalf("yamlFile.Get err %v ", err)
		}
	}
	err = yaml.Unmarshal(configFile, &config)
	if err != nil {
		log.Fatalf("yamlFile.Get err %v ", err)
	}
}
