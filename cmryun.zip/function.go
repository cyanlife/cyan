package cmryun

import (
	"archive/zip"

	"crypto/md5"
	"crypto/tls"
	"database/sql"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"sort"
	"strings"

	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin/json"
	//"github.com/gorilla/mux"
)

func Request(r *http.Request, key string) string {
	r.ParseForm()
	if len(r.Form[key]) > 0 {
		return r.Form[key][0]
	}
	return ""
}

func AspCookie(r *http.Request, key string, sub string) string {
	cookie, err := r.Cookie(key)
	if err != nil {
		return ""
	}
	if sub == "" {
		return cookie.Value
	}
	cookies := strings.Split(cookie.Value, ";")
	for i := 0; i < len(cookies); i++ {
		ck := strings.Split(cookies[i], "=")
		if len(ck) > 1 && ck[0] == sub {
			return ck[1]
		}
	}
	return ""
}

func HttpGet(url string) (string, error) {
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	resp, err := client.Get(url)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	//fmt.Println(string(body) + url)
	return string(body), err

}

func HttpPostByte(url string, data string) ([]byte, error) {
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	resp, err := client.Post(url,
		"application/x-www-form-urlencoded",
		strings.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return ioutil.ReadAll(resp.Body)

}

func HttpPost(url string, data string) (string, error) {

	body, err := HttpPostByte(url, data)
	//fmt.Println(string(body) + url)
	return string(body), err

}

func ArrayStringfly(data map[string]string) string {
	str := ""
	for k, v := range data {
		str += k + "=" + v + "&"
	}
	return strings.TrimRight(str, "&")
}

func BuildMd5SignString(data map[string]string, sign string) string {
	str := ArrayStringflySort(data) + "&key=" + sign
	//fmt.Println("sign:", str)
	return Md5(str)
}

func ArrayStringflySort(data map[string]string) string {
	str := ""
	var b []string
	for k, v := range data {
		//fmt.Println(k, v)
		v = v
		b = append(b, k)
	}
	sort.Strings(b)
	for k, v := range b {
		k = k
		str += v + "=" + data[v] + "&"
	}
	return strings.TrimRight(str, "&")
}

func MapString(obj map[string]interface{}) map[string]string {
	data := make(map[string]string)
	for key, value := range obj {
		if value != nil {
			data[key] = value.(string)
		}
	}
	return data
}

func Md5(str string) string {
	data := []byte(str)
	has := md5.Sum(data)
	return fmt.Sprintf("%x", has)
}

func RowToJSONString(rows *sql.Rows) (string, error) {

	defer rows.Close()
	columns, err := rows.Columns()
	if err != nil {
		return "", err
	}
	count := len(columns)
	tableData := make([]map[string]interface{}, 0)
	values := make([]interface{}, count)
	valuePtrs := make([]interface{}, count)
	for rows.Next() {
		for i := 0; i < count; i++ {
			valuePtrs[i] = &values[i]
		}
		rows.Scan(valuePtrs...)
		entry := make(map[string]interface{})
		for i, col := range columns {
			var v interface{}
			val := values[i]
			b, ok := val.([]byte)
			if ok {
				v = string(b)
			} else {
				v = val
			}
			entry[col] = v
		}
		tableData = append(tableData, entry)
	}
	jsonData, err := json.Marshal(tableData)
	if err != nil {
		return "", err
	}
	fmt.Println(string(jsonData))
	return string(jsonData), nil
}

func RowToJSON(rows *sql.Rows) ([]map[string]interface{}, error) {

	tableData := make([]map[string]interface{}, 0)

	defer rows.Close()
	columns, err := rows.Columns()
	if err != nil {
		return tableData, err
	}
	count := len(columns)
	values := make([]interface{}, count)
	valuePtrs := make([]interface{}, count)
	for rows.Next() {
		for i := 0; i < count; i++ {
			valuePtrs[i] = &values[i]
		}
		rows.Scan(valuePtrs...)
		entry := make(map[string]interface{})
		for i, col := range columns {
			var v interface{}
			val := values[i]
			b, ok := val.([]byte)
			if ok {
				v = string(b)
			} else {
				v = val
			}
			entry[col] = v
		}
		tableData = append(tableData, entry)
	}
	return tableData, nil
}

func InArray(array []string, url string) bool {
	for i := 0; i < len(array); i++ {
		if array[i] == url {
			return true
		}
	}
	return false
}

func MergeSlice(s1 []string, s2 []string) []string {
	slice := make([]string, len(s1)+len(s2))
	copy(slice, s1)
	copy(slice[len(s1):], s2)
	return slice
}

func MapExtend(s1 map[string]string, s2 map[string]string) map[string]string {
	for k, v := range s2 {
		s1[k] = v
	}
	return s1
}

func BuildJWT(data jwt.MapClaims, key string) string {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, data)
	tokenString, err := token.SignedString([]byte(key))

	if err != nil {
		return ""
	}
	return tokenString
}

func ParseJWT(tokenString string, key string) jwt.MapClaims {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		// Don't forget to validate the alg is what you expect:
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
		return []byte(key), nil
	})

	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		return claims
	} else {
		fmt.Println(err)
		return nil
	}

}

//压缩文件
//files 文件数组，可以是不同dir下的文件或者文件夹
//dest 压缩文件存放地址
func CompressFiles(files []*os.File, dest string) error {
	d, _ := os.Create(dest)
	defer d.Close()
	w := zip.NewWriter(d)
	defer w.Close()
	for _, file := range files {
		err := Compress(file, "", w)
		if err != nil {
			return err
		}
	}
	return nil
}

func Compress(file *os.File, prefix string, zw *zip.Writer) error {
	info, err := file.Stat()
	if err != nil {
		return err
	}
	if info.IsDir() {
		prefix = prefix + info.Name()
		fileInfos, err := file.Readdir(-1)
		if err != nil {
			return err
		}
		for _, fi := range fileInfos {
			f, err := os.Open(file.Name() + "/" + fi.Name())
			if err != nil {
				return err
			}
			err = Compress(f, prefix, zw)
			if err != nil {
				return err
			}
		}
	} else {
		header, err := zip.FileInfoHeader(info)
		header.Name = prefix + header.Name
		if err != nil {
			return err
		}
		writer, err := zw.CreateHeader(header)
		if err != nil {
			return err
		}
		_, err = io.Copy(writer, file)
		file.Close()
		if err != nil {
			return err
		}
	}
	return nil
}
