package cmryun

import (
	"context"
	"database/sql"
	"net/http"

	"github.com/go-gorp/gorp"

	"gopkg.in/mgo.v2"
)

type H map[string]interface{}

func AccessControl(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		//fmt.Println("AccessControl:")
		query := r.URL.Query()
		pid := query.Get("pid")
		r = ContextSet(r, "pid", pid)
		if cookie, err := r.Cookie(pid + "%5Fp%5Fuid"); err == nil {
			r = ContextSet(r, "uid", cookie.Value)
		}
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type")

		if r.Method == "OPTIONS" {
			return
		}

		h.ServeHTTP(w, r)
	})
}

func CheckAccess(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Do stuff here

		if token, err := r.Cookie("token"); err != nil {
			http.Error(w, "Forbidden", http.StatusForbidden)
		} else {
			MapClaims := ParseJWT(token.Value, "cmr123")
			r = ContextSet(r, "pid", MapClaims["pid"])
			r = ContextSet(r, "uid", MapClaims["uid"])
			//fmt.Println("CheckAccess:", r.RequestURI, token)
			next.ServeHTTP(w, r)
		}

	})
}

func ContextGet(r *http.Request, key interface{}) interface{} {
	return r.Context().Value(key)
}

func ContextSet(r *http.Request, key, val interface{}) *http.Request {
	if val == nil {
		return r
	}

	return r.WithContext(context.WithValue(r.Context(), key, val))
}

func ContextClear(r *http.Request) {
	return
}

func GetDB(driver string) (*gorp.DbMap, error) {
	conn := config[driver].(map[interface{}]interface{})
	db, err := sql.Open(driver, conn["main"].(string))
	return &gorp.DbMap{Db: db, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}, err
}

func GetMDB(db string) (*mgo.Database, error) {
	conn := config["mongo"].(map[interface{}]interface{})
	session, err := mgo.Dial(conn["main"].(string))
	if err != nil {
		return nil, err
	}
	session.SetMode(mgo.Primary, true)
	return session.DB(db), err
}

func GetDownUrl() string {
	if config["downurl"] == nil {
		return ""
	}
	url := config["downurl"].(string)
	return url
}
