package cmryun

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strings"
	"time"

	"github.com/buger/jsonparser"
)

type AuthInfo struct {
	Uid            string
	Pid            string
	Mode           string
	U              string
	UserPort       string
	AgencyId       string
	Did            string
	DeptId         string
	UserIP         string
	PureCurUrl     string
	CurUrlPath     string
	Referer        string
	RefTopDomain   string
	NeedCheckUid   bool
	ValidUserLogin bool
	R              *http.Request
	W              http.ResponseWriter
}

func OldAuth(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		a := AuthInfo{
			R: r,
			W: w,
		}
		//Init(r)
		a.Mode = Request(r, "mode")
		a.Pid = Request(r, "pid")
		if a.Pid == "" {
			a.Pid = Request(r, "hidPid")
		}
		a.PureCurUrl = r.Proto + "://" + r.Host + r.URL.Path
		fmt.Println(a.PureCurUrl)
		if a.Pid == "" {
			a.Pid = GetPidFromDomain(a.PureCurUrl)
		}
		a.U = Request(r, "u")

		cookie := a.Pid + "_uid"
		a.UserPort = AspCookie(r, cookie, "u_p")
		a.DeptId = AspCookie(r, cookie, "approval_deptId")
		a.AgencyId = AspCookie(r, cookie, "agencyId")
		a.Did = AspCookie(r, cookie, "deptId")
		if a.UserPort == "" && a.Mode == "s" {
			a.UserPort = AspCookie(r, cookie, "i_u_p")
		}
		if a.AgencyId == "" && a.Mode == "s" {
			a.AgencyId = AspCookie(r, cookie, "i_agencyId")
		}
		if a.Did == "" && a.Mode == "s" {
			a.Did = AspCookie(r, cookie, "i_deptId")
		}
		if a.DeptId == "" && a.Mode == "s" {
			a.Did = AspCookie(r, cookie, "i_approval_deptId")
		}

		a.Uid = AspCookie(r, cookie, "uid")
		if a.Uid == "" && a.Mode == "s" {
			a.Uid = AspCookie(r, cookie, "i_uid")
		}

		a.Referer = r.Header.Get("referer")
		if a.Referer != "" {
			a.Referer = strings.Split(a.Referer, "?")[0]
			reg, _ := regexp.Compile(`(\w*\.(com.cn|com|net.cn|net))`)
			a.RefTopDomain = reg.FindString(a.Referer)
		}
		a.UserIP = r.Header.Get("X-Forwarded-For")

		a.CurUrlPath = r.URL.Path

		result, err := a.multipleCheckLogin()

		ContextSet(r, "auth", a)

		orgin := r.Header.Get("origin")
		if strings.Contains(orgin, TOP_DOMAIN) {
			w.Header().Set("Access-Control-Allow-Origin", orgin)
			w.Header().Set("Access-Control-Allow-Credentials", "true")
		}
		//c.Next()
		//return
		// before request
		if result == 1000 && err == "" {
			h.ServeHTTP(w, r)
		} else {
			EchoApiResult(w, map[string]interface{}{
				"error":   err,
				"message": result,
			})
		}

	})
}

/*
 * 验证权限
 */
func (a AuthInfo) multipleCheckLogin() (int, string) {
	return 1000, ""
	if strings.Index(a.CurUrlPath, "/media/") == 0 {
		return 1000, ""
	}
	if a.CurUrlPath == "/login" || a.CurUrlPath == "/register" || a.CurUrlPath == "/errorinfo" || a.CurUrlPath == "/favicon.ico" {
		return 1000, ""
	}

	if InArray(ValidUrl, a.PureCurUrl) {
		return 1000, ""
	}
	fmt.Println(a.PureCurUrl)
	url := GetDomain("authSysDomain") + "/auth/intf/menuInfoMultiple"
	data := map[string]string{
		"pid":     a.Pid,
		"mode":    "s",
		"i_uid":   a.Uid,
		"i_u_p":   a.UserPort,
		"menuUrl": strings.Replace(a.PureCurUrl, "https", "http", 1),
		"state":   "1",
		"deptid":  a.Did,
		"token":   "",
		"i_time":  time.Now().Format("2006-01-02@15:04:05"),
	}
	data["i_sign"] = BuildSign(data)
	response, err := HttpPost(url, ArrayStringfly(data))
	if err != nil {
		return 3001, err.Error()
	}
	menu := []byte(response)
	if value, err := jsonparser.GetString(menu, "error"); err == nil && value != "" {
		return 3002, value
	}
	detail, dataType, offset, err := jsonparser.Get(menu, "menuDetail")
	dataType = dataType
	offset = offset
	if value, err := jsonparser.GetInt(menu, "menuType"); err == nil && value != 3 {
		return a.checkPage(detail)
	} else {
		return a.checkApi(detail)
	}

}

/*
 * 验证接口
 */
func (a AuthInfo) checkApi(menu []byte) (int, string) {

	isSysManageSys := false
	if strings.Contains(a.PureCurUrl, GetDomain("sysManageDomain")) {
		isSysManageSys = true
	}

	if a.Mode == "" {
		//缺少参数
		return 2001, ""
	}
	if a.Mode != "c" && a.Mode != "s" {
		//请求模式不正确
		return 2002, ""
	}
	if isSysManageSys && a.U == "" {
		//缺少参数
		return 2004, ""
	}
	if !isSysManageSys && a.U != "f" && a.U != "b" {
		//请求用户端口参数不正确
		return 2005, ""
	}
	mt, err := jsonparser.GetString(menu, "menuPortType")
	if err == nil && !isSysManageSys && !strings.Contains(mt, a.U) {
		//'接口未对当前调用用户端开放';
		return 2006, mt
	}
	lrm, err := jsonparser.GetString(menu, "limitReqMode")
	if err == nil && lrm != "" && lrm != a.Mode {
		//'接口未对当前调用用户端开放';
		return 2003, lrm
	}

	if ift, err := jsonparser.GetString(menu, "interfaceType"); err == nil && ift == "2" {
		a.NeedCheckUid = true
	}
	if ils, err := jsonparser.GetBoolean(menu, "limitLoginStatus"); err == nil && ils {
		a.NeedCheckUid = true
	}
	if a.U == "b" {
		a.NeedCheckUid = true
	}

	if a.NeedCheckUid && !isSysManageSys && a.U != a.UserPort {
		//用户所属端口与请求端口不符,所属端口
		return 2007, ""
	}
	if a.Mode == "c" {
		return a.checkClientApi(menu)
	}
	if a.Mode == "s" {
		return a.checkServerApi(menu)
	}

	return 1000, ""
}

/*
 * 验证客户端接口
 */
func (a AuthInfo) checkClientApi(menu []byte) (int, string) {
	if a.Referer == "" {
		return 2101, ""
	}
	if a.RefTopDomain != TOP_DOMAIN {
		return 2102, ""
	}
	p, err := jsonparser.GetBoolean(menu, "isIpLimit")
	v, err := jsonparser.GetString(menu, "validIp")
	if err == nil && p && !strings.Contains(v, a.UserIP) {
		//'接口未对当前调用用户端开放';
		return 2003, ""
	}
	p, err = jsonparser.GetBoolean(menu, "isHttpFromLimit")
	v, err = jsonparser.GetString(menu, "validHttpReferer")
	if err == nil && p && !strings.Contains(v, a.Referer) {
		//'接口未对当前调用用户端开放';
		return 2003, ""
	}
	if a.NeedCheckUid {
		return CheckCookieUid(a.W, a.R, a.Pid, true, true)
	}
	return 1000, ""
}

/*
 * 验证服务器端接口
 */
func (a AuthInfo) checkServerApi(menu []byte) (int, string) {
	if ipt, err := jsonparser.GetInt(menu, "interfacePortType"); err == nil && ipt == 1 {
		if !InArray(ValidServerIp["all"], a.UserIP) && !InArray(ValidServerIp[a.Pid], a.UserIP) {
			return 2201, a.UserIP
		}
		if vp, err := jsonparser.GetString(menu, "validProjId"); err == nil {
			if InArray(strings.Split(vp, ";"), a.UserIP) {
				return 2207, ""
			}
		}
	} else if !InArray(ValidServerIp["all"], a.UserIP) {
		return 2201, ""
	}
	p, err := jsonparser.GetBoolean(menu, "isHttpFromLimit")
	v, err := jsonparser.GetString(menu, "validHttpReferer")
	if err == nil && p && !strings.Contains(v, a.Referer) {
		//"不是合法的服务器端接口请求来源";
		return 2202, ""
	}
	oriSign := Request(a.R, "i_sign")
	postForm := a.R.PostForm
	fmt.Println("postForm", postForm)
	postForm.Del("i_sign")
	postForm.Del("callback")
	var sDic map[string]string
	sDic = make(map[string]string)
	for k, v := range postForm {
		//if len(v) > 0 {
		sDic[k] = v[0]
		//}
	}
	fmt.Println("sDic", sDic)
	i_time := Request(a.R, "i_time")
	oriTime, err := time.Parse("2006-01-02@15:04:05", i_time)
	if err != nil {
		return 2205, err.Error()
	}
	if oriSign == "" {
		return 2206, ""
	}
	sign := BuildSign(sDic)
	if sign != oriSign {
		return 2204, sign + "--" + oriSign
	}
	oriTime.Add(time.Minute * COOKIE_VALID_TIME)
	if oriTime.Before(time.Now()) {
		return 2205, ""
	}
	return 1000, ""
}

/*
 * 验证功能
 */
func (a AuthInfo) checkPage(menu []byte) (int, string) {
	if mt, err := jsonparser.GetString(menu, "menuPortType"); err == nil && mt == "b" {
		if a.Referer == "" && a.RefTopDomain != TOP_DOMAIN {
			//'您不是合法管理端用户';
			return 2301, ""
		}
		if a.UserPort != "b" {
			//'用户所属端口不合法';
			return 2302, ""
		}
		result, errors := CheckCookieUid(a.W, a.R, a.Pid, true, true)
		if result == 1000 {
			a.ValidUserLogin = true
		}
		return result, errors
	} else {
		if a.Referer == "" && a.RefTopDomain != TOP_DOMAIN {
			if v, err := jsonparser.GetInt(menu, "associatedFileType"); err == nil && v == 2 {
				//'您不是合法管理端用户';
				return 2303, ""
			}
		}
		if v, err := jsonparser.GetBoolean(menu, "limitLoginStatus"); err == nil && v {
			result, errors := CheckCookieUid(a.W, a.R, a.Pid, true, true)
			if result == 1000 {
				a.ValidUserLogin = true
			}
			if a.Pid != "cnugp" && !strings.Contains(mt, a.UserPort) {
				return 2304, ""
			}
			return result, errors
		}
		return 1000, ""
	}

}

/*
 *  验证cookie
 */
func CheckCookieUid(w http.ResponseWriter, r *http.Request, pid string, refresh bool, domain bool) (int, string) {
	cookieName := pid + "_uid"
	if AspCookie(r, cookieName, "") == "" {
		return 2401, ""
	}
	uid := AspCookie(r, cookieName, "uid")
	c_time := AspCookie(r, cookieName, "c_time")
	signCheck := AspCookie(r, cookieName, "sn")
	agencyId := AspCookie(r, cookieName, "agencyId")
	deptId := AspCookie(r, cookieName, "deptId")
	adid := AspCookie(r, cookieName, "approval_deptId")
	u_p := AspCookie(r, cookieName, "u_p")
	user_ip := AspCookie(r, cookieName, "u_ip")
	ck_pid := AspCookie(r, cookieName, "pid")
	if uid != "" || c_time != "" || signCheck != "" || u_p != "" || ck_pid != "" {
		return 2402, ""
	}
	if pid != ck_pid {
		return 2403, ""
	}
	tmpDic := map[string]string{
		"c_time": c_time,
		"pid":    ck_pid,
		"uid":    uid,
		"u_p":    u_p,
	}
	if pid == "cmr" {
		if deptId != "" {
			tmpDic["deptId"] = deptId
			tmpDic["approval_deptId"] = adid
		}
	} else if strings.Contains(APPROVAL_DEPT_COOKIE_PID, ";"+pid+";") {
		tmpDic["approval_deptId"] = adid
	}
	if strings.Contains(AGENCY_COOKIE_PID, ";"+pid+";") {
		tmpDic["agencyId"] = agencyId
		tmpDic["u_ip"] = user_ip
	}
	sign := BuildSignPid(tmpDic, pid, "cookieKey")
	if sign != signCheck {
		return 2403, sign + "--" + signCheck
	}
	dateTime, err := time.Parse("2006-01-02@15:04:05", c_time)
	dateTime.Add(time.Minute * COOKIE_VALID_TIME)
	if err == nil && dateTime.Before(time.Now()) {
		return 2405, ""
	}
	if refresh {
		tmpDic["c_time"] = time.Now().Format("2006-01-02@15:04:05")
		tmpDic["sn"] = BuildSign(tmpDic)
		if strings.Contains(AGENCY_COOKIE_PID, ";"+pid+";") {
			tmpDic["agencyId"] = strings.Replace(agencyId, ",", "%2C", -1)
		}
		cookie := http.Cookie{Name: cookieName, Value: ArrayStringfly(tmpDic), Path: "/", MaxAge: 0}
		if domain {
			//c.SetCookie(cookie, ArrayStringfly(tmpDic), 0, "/", TOP_DOMAIN, true, true)
			cookie.Domain = TOP_DOMAIN
		}
		http.SetCookie(w, &cookie)

	}
	return 1000, ""
}

func GetPidFromDomain(url string) string {
	return "hd"
}

func BuildSign(data map[string]string) string {
	return BuildSignPid(data, "i", "Key")
}

func BuildSignPid(data map[string]string, pid string, key string) string {
	keys := config["keys"].(map[interface{}]interface{})
	keyValue := keys[pid+"_"+key].(string)
	return BuildMd5SignString(data, keyValue)
}

func EchoApiResult(w http.ResponseWriter, data interface{}) {
	json.NewEncoder(w).Encode(data)
}
