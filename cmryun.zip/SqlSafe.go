package cmryun

import (
	"regexp"

	"net/http"
)

func SqlSafe(r *http.Request) bool {

	getfilter := `'|(and|or)\\b.+?(>|<|=|in|like)|\\/\\*.+?\\*\\/|<\\s*script\\b|\\bEXEC\\b|UNION.+?SELECT|UPDATE.+?SET|INSERT\\s+INTO.+?VALUES|(SELECT|DELETE).+?FROM|(CREATE|ALTER|DROP|TRUNCATE)\\s+(TABLE|DATABASE)`
	postfilter := `\\b(and|or)\\b.{1,6}?(=|>|<|\\bin\\b|\\blike\\b)|\\/\\*.+?\\*\\/|<\\s*script\\b|\\bEXEC\\b|UNION.+?SELECT|UPDATE.+?SET|INSERT\\s+INTO.+?VALUES|(SELECT|DELETE).+?FROM|(CREATE|ALTER|DROP|TRUNCATE)\\s+(TABLE|DATABASE)`
	cookiefilter := `\\b(and|or)\\b.{1,6}?(=|>|<|\\bin\\b|\\blike\\b)|\\/\\*.+?\\*\\/|<\\s*script\\b|\\bEXEC\\b|UNION.+?SELECT|UPDATE.+?SET|INSERT\\s+INTO.+?VALUES|(SELECT|DELETE).+?FROM|(CREATE|ALTER|DROP|TRUNCATE)\\s+(TABLE|DATABASE)`
	for k, v := range r.PostForm {
		k = k
		if match, _ := regexp.MatchString(postfilter, v[0]); match {
			return false
		}
	}
	for k, v := range r.Form {
		k = k
		if match, _ := regexp.MatchString(getfilter, v[0]); match {
			return false
		}
	}
	for k, v := range r.Cookies() {
		k = k
		if match, _ := regexp.MatchString(cookiefilter, v.Value); match {
			return false
		}
	}
	return true

}
